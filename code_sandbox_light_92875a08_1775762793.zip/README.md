# ShopForMe KE 🛒

**Nairobi's personal shopping & delivery service website.**

> "We Shop. You Relax." — A mobile-first static website that converts visitors into WhatsApp orders.

---

## 🚀 Project Overview

ShopForMe KE is a convenience service that helps busy Nairobi residents save time by handling grocery shopping and household purchases. This website's **primary goal** is to drive visitors to message instantly on WhatsApp.

---

## ✅ Completed Features

### Pages & Sections
- **Hero Section** — Bold headline, WhatsApp CTA, animated background shapes, stats bar
- **Trust Bar** — Scrollable social proof strip
- **How It Works** — 3-step visual process with step connectors
- **Services Section** — 4 service cards (Grocery, Fresh Produce, Household, Bulk)
- **Why Choose Us** — 6 benefit cards with icons
- **Pricing Section** — 3 transparent pricing cards + no-hidden-charges note
- **Testimonials** — 3 customer review cards
- **CTA Section** — Full-width gradient banner with dual buttons
- **Contact / Order Form** — Full form with WhatsApp prefill on submit
- **Footer** — 3-column footer with links and contact info

### Features
- 📱 **Mobile-first responsive design** (320px → 1280px+)
- 💬 **Sticky WhatsApp button** — always visible, collapses on scroll down
- 📝 **Smart order form** — submits directly to WhatsApp with prefilled message
- 📎 **Upload shopping list** — drag & drop or file picker (JPG/PNG/PDF/TXT/DOC)
- 🎯 **Active nav highlighting** — tracks scroll position
- 🔢 **Animated counters** — hero stats count up on scroll into view
- ✨ **Scroll fade-in animations** — staggered for all cards and sections
- 🍔 **Mobile navigation** — hamburger menu with smooth open/close
- ⬆️ **Back-to-top button** — appears after scrolling 400px
- 🍞 **Toast notifications** — form validation & success messages
- 🎨 **Page load fade-in** — smooth entry animation
- ⚡ **Fast-loading** — CDN-only dependencies, optimized CSS/JS

### Design & Branding
- **Colors:** Green (#16a34a), Blue (#1d4ed8), White — clean and fresh
- **Typography:** Inter (Google Fonts) — modern, readable on mobile
- **Icons:** Font Awesome 6 — shopping, delivery, trust icons
- **WhatsApp:** #25d366 — consistent branding throughout

---

## 📁 File Structure

```
index.html          Main HTML file
css/
  style.css         All styles (mobile-first, responsive)
js/
  main.js           All JavaScript (navbar, form, animations, etc.)
README.md           Project documentation
```

---

## 🔗 Functional Entry Points

| Section | Anchor |
|---------|--------|
| Home / Hero | `#home` |
| How It Works | `#how-it-works` |
| Services | `#services` |
| Why Choose Us | `#why-us` |
| Pricing | `#pricing` |
| Testimonials | `#testimonials` |
| Contact / Order | `#contact` |

### WhatsApp Links
- **Quick order:** `https://wa.me/254716446845?text=Hi!%20I'd%20like%20to%20place%20an%20order`
- **Price quote:** `https://wa.me/254716446845?text=Hi!%20I'd%20like%20to%20know%20the%20exact%20cost`
- **General chat:** `https://wa.me/254716446845`

### Phone
- `tel:+254716446845`

---

## 📊 Data Models

No database required. This is a static lead-capture site. All orders are routed via WhatsApp.

**Order form fields:**
- Name (text, required)
- Phone (tel, required)
- Delivery Location (text, required)
- Shopping List (textarea, required)
- File Upload (optional, max 5MB)
- Special Notes (optional)

---

## 🔧 Technologies Used

| Technology | Purpose |
|-----------|---------|
| HTML5 | Structure & semantics |
| CSS3 | Mobile-first styling, animations |
| JavaScript (vanilla) | Interactivity, form handling |
| Google Fonts (Inter) | Typography |
| Font Awesome 6 CDN | Icons |
| WhatsApp API | Primary order channel |

---

## 🚧 Features Not Yet Implemented

- [ ] Real-time order tracking page
- [ ] Customer login / order history
- [ ] Multi-language support (English/Swahili)
- [ ] Blog / tips section
- [ ] Google Maps service area map
- [ ] Price calculator tool
- [ ] FAQ accordion section
- [ ] Instagram feed integration
- [ ] Push notification opt-in

---

## 💡 Recommended Next Steps

1. **Add FAQ section** — answer common questions about delivery times, payment methods
2. **Payment info page** — M-Pesa payment instructions
3. **WhatsApp Business integration** — automated reply when message is received
4. **Google My Business listing** — boost local SEO
5. **Swahili version** — reach more Nairobi customers
6. **Instagram/TikTok links** — social proof and viral marketing
7. **Order tracking status page** — simple status updates via WhatsApp number lookup
8. **Analytics** — add Google Analytics 4 to track conversions

---

## 📞 Business Info

- **Service Name:** ShopForMe KE
- **Location:** Nairobi, Kenya
- **Phone/WhatsApp:** 0716 446 845
- **Hours:** Mon–Sat, 7AM – 8PM
- **Starting Fee:** Ksh 300 shopping fee + delivery

---

*Built with ❤️ for Nairobi's busiest people.*
