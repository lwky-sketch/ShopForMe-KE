/* ======================================
   ShopForMe KE – Main JavaScript
   ====================================== */

'use strict';

/* --------- Navbar: scroll shadow & mobile toggle --------- */
(function initNavbar() {
  const navbar = document.getElementById('navbar');
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');

  // Scroll shadow
  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  }, { passive: true });

  // Mobile toggle
  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    navToggle.classList.toggle('active', isOpen);
    navToggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
  });

  // Close mobile nav on link click
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      navToggle.classList.remove('active');
    });
  });

  // Close on outside click
  document.addEventListener('click', (e) => {
    if (!navbar.contains(e.target)) {
      navLinks.classList.remove('open');
      navToggle.classList.remove('active');
    }
  });
})();


/* --------- Smooth active nav link highlighting --------- */
(function initActiveNav() {
  const sections = document.querySelectorAll('section[id]');
  const links = document.querySelectorAll('.nav-link');

  function updateActive() {
    let currentId = '';
    const scrollY = window.scrollY + 80;

    sections.forEach(sec => {
      if (scrollY >= sec.offsetTop) {
        currentId = sec.id;
      }
    });

    links.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${currentId}`) {
        link.classList.add('active');
      }
    });
  }

  window.addEventListener('scroll', updateActive, { passive: true });
  updateActive();
})();


/* --------- Back to top button --------- */
(function initBackToTop() {
  const btn = document.getElementById('backToTop');

  window.addEventListener('scroll', () => {
    btn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
})();


/* --------- Scroll-triggered fade-in animations --------- */
(function initScrollAnimations() {
  // Add fade-in class to elements
  const animatables = [
    '.step-card',
    '.service-card',
    '.why-card',
    '.pricing-card',
    '.testimonial-card',
    '.section-header',
    '.contact-info',
    '.contact-form-wrap',
    '.hero-stats',
    '.trust-item',
  ];

  animatables.forEach(selector => {
    document.querySelectorAll(selector).forEach((el, i) => {
      el.classList.add('fade-in-up');
      // Stagger by index within parent
      const delay = Math.min(i * 0.1, 0.4);
      el.style.transitionDelay = `${delay}s`;
    });
  });

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.fade-in-up').forEach(el => observer.observe(el));
})();


/* --------- File Upload Handling --------- */
(function initFileUpload() {
  const fileInput = document.getElementById('list-upload');
  const filePreview = document.getElementById('filePreview');
  const uploadArea = document.getElementById('fileUploadArea');
  const uploadContent = uploadArea ? uploadArea.querySelector('.file-upload-content') : null;

  if (!fileInput || !filePreview || !uploadArea) return;

  function handleFile(file) {
    if (!file) return;

    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      showToast('File too large. Please upload files under 5MB.', 'error');
      return;
    }

    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf',
      'text/plain', 'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

    if (!allowedTypes.includes(file.type) && !file.name.match(/\.(jpg|jpeg|png|pdf|txt|doc|docx)$/i)) {
      showToast('File type not supported. Please use JPG, PNG, PDF, TXT, or DOC.', 'error');
      return;
    }

    const icon = getFileIcon(file.type, file.name);
    const size = formatFileSize(file.size);
    filePreview.innerHTML = `
      <div class="file-selected">
        <span>${icon} <strong>${escapeHtml(file.name)}</strong> (${size})</span>
        <button type="button" class="file-remove" onclick="removeFile()" aria-label="Remove file">✕</button>
      </div>
    `;
    if (uploadContent) uploadContent.style.opacity = '0.5';
    uploadArea.style.borderColor = 'var(--green)';
    uploadArea.style.background = 'var(--green-bg)';
  }

  fileInput.addEventListener('change', (e) => {
    handleFile(e.target.files[0]);
  });

  // Drag and drop
  uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('dragover');
  });
  uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('dragover');
  });
  uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
    handleFile(e.dataTransfer.files[0]);
  });

  // Expose remove function globally
  window.removeFile = function () {
    fileInput.value = '';
    filePreview.innerHTML = '';
    if (uploadContent) uploadContent.style.opacity = '1';
    uploadArea.style.borderColor = '';
    uploadArea.style.background = '';
  };

  function getFileIcon(type, name) {
    if (type.startsWith('image/')) return '🖼️';
    if (type === 'application/pdf' || name.endsWith('.pdf')) return '📄';
    if (type.includes('word') || name.match(/\.docx?$/)) return '📝';
    return '📎';
  }

  function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + 'B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + 'KB';
    return (bytes / (1024 * 1024)).toFixed(1) + 'MB';
  }

  function escapeHtml(str) {
    return str.replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }
})();


/* --------- Order Form: Open WhatsApp with prefilled message --------- */
(function initOrderForm() {
  const form = document.getElementById('orderForm');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = form.querySelector('#name').value.trim();
    const phone = form.querySelector('#phone').value.trim();
    const location = form.querySelector('#location').value.trim();
    const shoppingList = form.querySelector('#shopping-list').value.trim();
    const notes = form.querySelector('#notes').value.trim();
    const fileInput = document.getElementById('list-upload');
    const hasFile = fileInput && fileInput.files.length > 0;

    // Basic validation
    if (!name || !phone || !location || !shoppingList) {
      showToast('Please fill in all required fields.', 'error');
      return;
    }

    if (!/^[0-9\s\+\-\(\)]{7,15}$/.test(phone)) {
      showToast('Please enter a valid phone number.', 'error');
      form.querySelector('#phone').focus();
      return;
    }

    // Build WhatsApp message
    let message = `Hello ShopForMe KE! 🛒\n\n`;
    message += `*New Order Request*\n`;
    message += `────────────────────\n`;
    message += `👤 *Name:* ${name}\n`;
    message += `📞 *Phone:* ${phone}\n`;
    message += `📍 *Delivery Location:* ${location}\n\n`;
    message += `🛍️ *Shopping List:*\n${shoppingList}\n`;

    if (notes) {
      message += `\n📝 *Special Notes:*\n${notes}\n`;
    }

    if (hasFile) {
      message += `\n📎 *(I have a file to share – I'll send it in this chat)*\n`;
    }

    message += `\n────────────────────\n`;
    message += `Please confirm availability and pricing. Thank you!`;

    const encoded = encodeURIComponent(message);
    const waUrl = `https://wa.me/254716446845?text=${encoded}`;

    // Show loading state
    const submitBtn = form.querySelector('.btn-submit');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Opening WhatsApp...';
    submitBtn.disabled = true;

    setTimeout(() => {
      window.open(waUrl, '_blank', 'noopener,noreferrer');
      submitBtn.innerHTML = originalText;
      submitBtn.disabled = false;
      showToast('✅ WhatsApp opened! Send your message to complete the order.', 'success');
      form.reset();
      if (window.removeFile) window.removeFile();
    }, 600);
  });
})();


/* --------- Toast Notification --------- */
function showToast(message, type = 'success') {
  // Remove existing toast
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      toast.classList.add('show');
    });
  });

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 350);
  }, 3500);
}


/* --------- Sticky WhatsApp button: hide near nav and footer --------- */
(function initStickyWA() {
  const btn = document.getElementById('stickyWhatsapp');
  if (!btn) return;

  // Collapse text on scroll down, expand on scroll up
  let lastScrollY = window.scrollY;
  const waText = btn.querySelector('.sticky-wa-text');

  window.addEventListener('scroll', () => {
    const currentY = window.scrollY;
    const scrollingDown = currentY > lastScrollY && currentY > 150;

    if (scrollingDown) {
      // Compact mode
      if (waText) waText.style.display = 'none';
      btn.style.padding = '0.85rem';
      btn.style.borderRadius = '50%';
    } else {
      // Full mode
      if (waText) waText.style.display = '';
      btn.style.padding = '';
      btn.style.borderRadius = '';
    }

    lastScrollY = currentY;
  }, { passive: true });
})();


/* --------- Number counter animation for hero stats --------- */
(function initCounters() {
  const stats = document.querySelectorAll('.stat-num');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;

      const el = entry.target;
      const text = el.textContent;
      const numMatch = text.match(/\d+/);
      if (!numMatch) return;

      const target = parseInt(numMatch[0]);
      const prefix = text.substring(0, text.indexOf(numMatch[0]));
      const suffix = text.substring(text.indexOf(numMatch[0]) + numMatch[0].length);
      let current = 0;
      const increment = Math.ceil(target / 30);
      const duration = 1200;
      const stepTime = Math.floor(duration / (target / increment));

      const timer = setInterval(() => {
        current = Math.min(current + increment, target);
        el.textContent = prefix + current + suffix;
        if (current >= target) clearInterval(timer);
      }, stepTime);

      observer.unobserve(el);
    });
  }, { threshold: 0.5 });

  stats.forEach(stat => observer.observe(stat));
})();


/* --------- Smooth scroll for anchor links --------- */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const navHeight = document.getElementById('navbar')?.offsetHeight || 64;
      const targetPos = target.getBoundingClientRect().top + window.scrollY - navHeight - 8;
      window.scrollTo({ top: targetPos, behavior: 'smooth' });
    }
  });
});


/* --------- Add CSS for file-selected display --------- */
(function addDynamicStyles() {
  const style = document.createElement('style');
  style.textContent = `
    .file-selected {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.5rem 0.75rem;
      background: var(--green-pale);
      border-radius: 6px;
      font-size: 0.82rem;
      color: var(--green-dark);
      gap: 0.5rem;
    }
    .file-selected strong {
      font-weight: 600;
      max-width: 200px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      display: inline-block;
      vertical-align: middle;
    }
    .file-remove {
      background: none;
      border: none;
      cursor: pointer;
      font-size: 0.85rem;
      color: var(--gray-400);
      padding: 0.1rem 0.3rem;
      border-radius: 4px;
      transition: var(--transition);
      line-height: 1;
    }
    .file-remove:hover { color: #ef4444; background: #fee2e2; }
    .nav-link.active { color: var(--green); background: var(--green-bg); }
  `;
  document.head.appendChild(style);
})();


/* --------- Page load animation --------- */
document.addEventListener('DOMContentLoaded', () => {
  document.body.style.opacity = '0';
  document.body.style.transition = 'opacity 0.4s ease';
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      document.body.style.opacity = '1';
    });
  });
});
